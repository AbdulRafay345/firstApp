import React from 'react'
import { Text, View } from 'react-native'

export default function Shop (){
  
    return (
      <View>
        <Text>Shop</Text>
      </View>
    )
  }

